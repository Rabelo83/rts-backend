# Florida Public Transportation Agencies: Clever Devices API & GTFS Reference

This document provides a comprehensive technical reference for Florida public transportation agencies that utilize the Clever Devices system (specifically BusTime) for real-time ETA and transit tracking. For each confirmed agency, this guide details the direct GTFS static feed download URLs, Clever Devices BusTime API documentation links, GTFS-RT real-time feed URLs (where available), and public ETA portal URLs.

## Clever Devices BusTime Developer API Overview

The Clever Devices BusTime Developer API (Version 3) is a RESTful web service that allows developers to request and retrieve real-time data directly from the BusTime system [1]. Registered third-party developers can make HTTP GET requests and receive XML or JSON responses.

**Common API Endpoints:**
*   `/bustime/api/v3/gettime` - Retrieve current system time
*   `/bustime/api/v3/getvehicles` - Retrieve vehicle locations
*   `/bustime/api/v3/getroutes` - Retrieve the set of routes
*   `/bustime/api/v3/getdirections` - Retrieve directions for a route
*   `/bustime/api/v3/getstops` - Retrieve stops for a route and direction
*   `/bustime/api/v3/getpatterns` - Retrieve geo-positional points and stops
*   `/bustime/api/v3/getpredictions` - Retrieve arrival predictions
*   `/bustime/api/v3/getservicebulletins` - Retrieve service bulletins

**Authentication:**
All requests to the API must be accompanied by a valid API key using the `?key=` parameter. Keys are typically obtained by creating an account on the agency's specific BusTime portal and requesting developer access [1].

---

## Agency Technical Details

### 1. Pinellas Suncoast Transit Authority (PSTA)
PSTA serves Pinellas County, including St. Petersburg and Clearwater.

*   **Public ETA Portal:** [https://ridepsta.net/bustime/home.jsp](https://ridepsta.net/bustime/home.jsp) [2]
*   **BusTime API Documentation:** [https://ridepsta.net/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://ridepsta.net/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf) [3]
*   **GTFS Static Feed URL:** [https://www.psta.net/latest/google_transit.zip](https://www.psta.net/latest/google_transit.zip) [4]
*   **GTFS-RT Feeds:** PSTA's real-time data is primarily accessed via their BusTime API rather than standard GTFS-RT protobuf endpoints.

### 2. Lee County Transit (LeeTran)
LeeTran provides public transportation services in Lee County, Florida.

*   **Public ETA Portal:** [https://bustime.leegov.com/bustime/home.jsp](https://bustime.leegov.com/bustime/home.jsp) [5]
*   **BusTime API Documentation:** [https://bustime.leegov.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://bustime.leegov.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf) [6]
*   **GTFS Static Feed URL:** [https://www.leegov.com/leetran/Documents/GTFS.zip](https://www.leegov.com/leetran/Documents/GTFS.zip) [7]
*   **GTFS-RT Feeds:** Real-time data is accessed via the BusTime API.

### 3. Miami-Dade Transit (MDT)
Miami-Dade Transit operates the Metrobus, Metrorail, and Metromover systems in Miami-Dade County.

*   **Public ETA Portal:** [https://transitbustime.miamidade.gov/](https://transitbustime.miamidade.gov/) [8]
*   **BusTime API Documentation:** [https://transitbustime.miamidade.gov/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://transitbustime.miamidade.gov/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf) [9]
*   **GTFS Static Feed URL:** [http://www.miamidade.gov/transit/googletransit/current/google_transit.zip](http://www.miamidade.gov/transit/googletransit/current/google_transit.zip) [10]
*   **GTFS-RT Feeds:** Miami-Dade Transit provides GTFS-RT feeds via Swiftly APIs [10].
    *   *Trip Updates:* `https://transitbustime.miamidade.gov/bustime/gtfsrt/gtfs-rt-trip-updates` (Requires authentication/API key)
    *   *Vehicle Positions:* `https://transitbustime.miamidade.gov/bustime/gtfsrt/gtfs-rt-vehicle-positions` (Requires authentication/API key)

### 4. Gainesville Regional Transit System (RTS)
Gainesville RTS serves the City of Gainesville and the University of Florida.

*   **Public ETA Portal:** [https://riderts.app/](https://riderts.app/) [11]
*   **BusTime API Documentation:** [https://riderts.app/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://riderts.app/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf) [12]
*   **GTFS Static Feed URL:** [http://go-rts.com/gtfs/google_transit.zip](http://go-rts.com/gtfs/google_transit.zip) [13]
*   **GTFS-RT Feeds:** Real-time data is accessed via the BusTime API.

### 5. Central Florida Regional Transportation Authority (LYNX)
LYNX provides public transportation services for Orange, Seminole, and Osceola counties (Orlando area).

*   **Public ETA Portal:** Integrated into the official LYNX apps and [http://gtfsrt.golynx.com/gtfsrt/](http://gtfsrt.golynx.com/gtfsrt/) data directory [14].
*   **BusTime API Documentation:** [http://gtfsrt.golynx.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](http://gtfsrt.golynx.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf) [15]
*   **GTFS Static Feed URL:** [http://gtfsrt.golynx.com/gtfsrt/google_transit.zip](http://gtfsrt.golynx.com/gtfsrt/google_transit.zip) [14]
*   **GTFS-RT Feeds:** LYNX provides direct, unauthenticated access to their GTFS-RT protobuf files [14]:
    *   *Trip Updates:* [http://gtfsrt.golynx.com/gtfsrt/GTFS_TripUpdates.pb](http://gtfsrt.golynx.com/gtfsrt/GTFS_TripUpdates.pb)
    *   *Vehicle Positions:* [http://gtfsrt.golynx.com/gtfsrt/GTFS_VehiclePositions.pb](http://gtfsrt.golynx.com/gtfsrt/GTFS_VehiclePositions.pb)
    *   *Service Alerts:* [http://gtfsrt.golynx.com/gtfsrt/GTFS_ServiceAlerts.pb](http://gtfsrt.golynx.com/gtfsrt/GTFS_ServiceAlerts.pb)

---

## References

[1] Clever Devices. "BusTime Developer API Version 3 Guide." [http://ride.smtd.org/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](http://ride.smtd.org/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf)
[2] Pinellas Suncoast Transit Authority. "RidePSTA.net Real Time Bus Information." [https://ridepsta.net/bustime/home.jsp](https://ridepsta.net/bustime/home.jsp)
[3] Pinellas Suncoast Transit Authority. "PSTA BusTime API Documentation." [https://ridepsta.net/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://ridepsta.net/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf)
[4] Pinellas Suncoast Transit Authority. "PSTA GTFS Static Feed." [https://www.psta.net/latest/google_transit.zip](https://www.psta.net/latest/google_transit.zip)
[5] Lee County Transit. "LeeTran Real Time Bus Information." [https://bustime.leegov.com/bustime/home.jsp](https://bustime.leegov.com/bustime/home.jsp)
[6] Lee County Transit. "LeeTran BusTime API Documentation." [https://bustime.leegov.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://bustime.leegov.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf)
[7] Lee County Government. "LeeTran GTFS Static Feed." [https://www.leegov.com/leetran/Documents/GTFS.zip](https://www.leegov.com/leetran/Documents/GTFS.zip)
[8] Miami-Dade County. "CD BusTime." [https://transitbustime.miamidade.gov/](https://transitbustime.miamidade.gov/)
[9] Miami-Dade County. "Miami-Dade BusTime API Documentation." [https://transitbustime.miamidade.gov/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://transitbustime.miamidade.gov/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf)
[10] Miami-Dade County. "Transit Open Data Feeds." [https://www.miamidade.gov/global/transportation/open-data-feeds.page](https://www.miamidade.gov/global/transportation/open-data-feeds.page)
[11] Gainesville Regional Transit System. "GNV RideRTS." [https://riderts.app/](https://riderts.app/)
[12] Gainesville Regional Transit System. "RTS BusTime API Documentation." [https://riderts.app/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](https://riderts.app/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf)
[13] Gainesville Regional Transit System. "RTS GTFS Static Feed." [http://go-rts.com/gtfs/google_transit.zip](http://go-rts.com/gtfs/google_transit.zip)
[14] LYNX. "LYNX GTFS and GTFS-RT Directory." [http://gtfsrt.golynx.com/gtfsrt/](http://gtfsrt.golynx.com/gtfsrt/)
[15] LYNX. "LYNX BusTime API Documentation." [http://gtfsrt.golynx.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf](http://gtfsrt.golynx.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf)
