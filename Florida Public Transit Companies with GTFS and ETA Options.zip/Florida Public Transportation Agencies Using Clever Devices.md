# Florida Public Transportation Agencies Using Clever Devices

This report identifies public transportation agencies in Florida that publish General Transit Feed Specification (GTFS) data and utilize the Clever Devices system (specifically BusTime) for real-time ETA and transit tracking.

## Identified Agencies

Through comprehensive research, the following Florida transit agencies have been confirmed to use Clever Devices for their real-time tracking portals and provide public GTFS data feeds.

### 1. Pinellas Suncoast Transit Authority (PSTA)
PSTA serves Pinellas County, including St. Petersburg and Clearwater. They use Clever Devices BusTime to power their real-time ETA portal.

*   **Public ETA Portal (BusTime):** [https://ridepsta.net/bustime/home.jsp](https://ridepsta.net/bustime/home.jsp) [1]
*   **GTFS Static Feed URL:** [http://www.psta.net/latest/Google_transit.zip](http://www.psta.net/latest/Google_transit.zip) [2]

### 2. Lee County Transit (LeeTran)
LeeTran provides public transportation services in Lee County, Florida. They launched their BusTime real-time information service powered by Clever Devices in 2017.

*   **Public ETA Portal (BusTime):** [https://bustime.leegov.com/bustime/home.jsp](https://bustime.leegov.com/bustime/home.jsp) [3]
*   **GTFS Static Feed URL:** [https://www.leegov.com/leetran/Documents/google_transit.zip](https://www.leegov.com/leetran/Documents/google_transit.zip) [4]

### 3. Miami-Dade Transit (MDT)
Miami-Dade Transit operates the Metrobus, Metrorail, and Metromover systems in Miami-Dade County. They utilize Clever Devices for their CAD/AVL and BusTime real-time tracking.

*   **Public ETA Portal (BusTime):** [https://transitbustime.miamidade.gov/](https://transitbustime.miamidade.gov/) [5]
*   **GTFS Static Feed URL:** [http://www.miamidade.gov/transit/googletransit/current/google_transit.zip](http://www.miamidade.gov/transit/googletransit/current/google_transit.zip) [6]

### 4. Gainesville Regional Transit System (RTS)
Gainesville RTS, which serves the City of Gainesville and the University of Florida, collaborated with Clever Devices to launch their GNVRideRTS app and web portal for real-time bus tracking.

*   **Public ETA Portal (BusTime):** [https://riderts.app/](https://riderts.app/) [7]
*   **GTFS Static Feed URL:** [https://go-rts.com/files/gtfs/google_transit.zip](https://go-rts.com/files/gtfs/google_transit.zip) (Available via [RTS Data Page](https://go-rts.com/rts-data/)) [8]

### 5. Central Florida Regional Transportation Authority (LYNX)
LYNX provides public transportation services for Orange, Seminole, and Osceola counties (Orlando area). They partnered with Clever Devices to provide real-time bus arrival information.

*   **Public ETA Portal (BusTime):** [http://gtfsrt.golynx.com/gtfsrt/](http://gtfsrt.golynx.com/gtfsrt/) (Data directory) and integrated into their official apps. [9]
*   **GTFS Static Feed URL:** [http://www.golynx.com/lynxmap/GoLYNX_data/google_transit.zip](http://www.golynx.com/lynxmap/GoLYNX_data/google_transit.zip) [10]

---

## Agencies Evaluated but Excluded

During the research process, several other major Florida transit agencies were evaluated but ultimately excluded from the final list because they do not use Clever Devices for their public-facing real-time ETA portals:

*   **Hillsborough Area Regional Transit (HART - Tampa):** While HART has contracted with Clever Devices for CAD/AVL upgrades, their current real-time data generation relies on OrbCAD, and their public ETA tracking is primarily handled through the Transit App rather than a dedicated Clever Devices BusTime web portal. [11]
*   **Palm Tran (Palm Beach County):** Palm Tran uses Avail Technologies for their real-time tracking portal, not Clever Devices. [12]
*   **Space Coast Area Transit (SCAT - Brevard County):** SCAT uses a different vendor for their real-time tracking and does not host a Clever Devices BusTime portal. [13]
*   **Jacksonville Transportation Authority (JTA):** JTA recently partnered with Clever Devices for AI-enhanced fleet reliability (AVM Prognostics), but their public-facing real-time tracking is integrated into their proprietary MyJTA app rather than a standard Clever Devices BusTime web portal. [14]

---

## References

[1] Pinellas Suncoast Transit Authority. "RidePSTA.net Real Time Bus Information." [https://ridepsta.net/bustime/home.jsp](https://ridepsta.net/bustime/home.jsp)
[2] Transitland. "GTFS feed: Pinellas Suncoast Transit Authority (PSTA)." [https://www.transit.land/feeds/f-dhv-psta](https://www.transit.land/feeds/f-dhv-psta)
[3] Lee County Transit. "LeeTran Real Time Bus Information." [https://bustime.leegov.com/bustime/home.jsp](https://bustime.leegov.com/bustime/home.jsp)
[4] Lee County Government. "General Transit Feed Specification." [https://www.leegov.com/leetran/gtfs](https://www.leegov.com/leetran/gtfs)
[5] Miami-Dade County. "CD BusTime." [https://transitbustime.miamidade.gov/](https://transitbustime.miamidade.gov/)
[6] Miami-Dade County. "Transit Open Data Feeds." [https://www.miamidade.gov/global/transportation/open-data-feeds.page](https://www.miamidade.gov/global/transportation/open-data-feeds.page)
[7] Gainesville Regional Transit System. "GNV RideRTS." [https://riderts.app/](https://riderts.app/)
[8] Gainesville Regional Transit System. "RTS Data." [https://go-rts.com/rts-data/](https://go-rts.com/rts-data/)
[9] Metro Magazine. "Fla.'s LYNX, Clever Devices team for bus tracking." [https://www.metro-magazine.com/news/fla-s-lynx-clever-devices-team-for-bus-tracking](https://www.metro-magazine.com/news/fla-s-lynx-clever-devices-team-for-bus-tracking)
[10] LYNX. "GIS and GTFS Data Download." [https://www.golynx.com/maps-schedules/data-download.stml](https://www.golynx.com/maps-schedules/data-download.stml)
[11] GitHub. "CUTR-at-USF/HART-GTFS-realtimeGenerator." [https://github.com/CUTR-at-USF/HART-GTFS-realtimeGenerator](https://github.com/CUTR-at-USF/HART-GTFS-realtimeGenerator)
[12] Palm Tran. "Palm Tran InfoPoint." [https://infopoint.palmtran.org/InfoPoint/](https://infopoint.palmtran.org/InfoPoint/)
[13] Space Coast Area Transit. "System map." [https://321transit.com/eta-maps/](https://321transit.com/eta-maps/)
[14] Clever Devices. "Jacksonville Transportation Authority (JTA) Collaborates with Clever Devices." [https://www.cleverdevices.com/news/jacksonville-transportation-authority-jta-collaborates-with-clever-devices-to-utilize-ai-for-enhanced-fleet-reliability/](https://www.cleverdevices.com/news/jacksonville-transportation-authority-jta-collaborates-with-clever-devices-to-utilize-ai-for-enhanced-fleet-reliability/)
