# Florida Transit Agencies — Clever Devices Complete Developer Reference

> **Purpose:** This document gives you everything needed to access real-time ETA data and static schedules for all confirmed Florida public transit agencies running on Clever Devices BusTime. No additional research required.

---

## How the Clever Devices BusTime API Works

The BusTime Developer API is a simple HTTP GET REST service. Every agency hosts it on their own subdomain. You send a request with your API key and get back XML or JSON.

**Base URL pattern:**
```
https://[agency-bustime-host]/bustime/api/v3/[endpoint]?key=YOUR_KEY&format=json
```

**How to get an API key (same steps for all agencies):**
1. Go to the agency's **API Key Request** URL listed below.
2. Create a free account with your name and email.
3. Sign in → click **My Account** (top right) → click **Developer API**.
4. Fill out the short request form.
5. You will receive your API key by email (usually within 1–2 business days).
6. Default limit: **10,000 requests/day** per key. Contact the agency to raise it.

---

## Key API Endpoints (Same for All 5 Agencies)

| Endpoint | Purpose | Required Parameters |
|---|---|---|
| `/gettime` | Current system time | `key` |
| `/getroutes` | List all routes | `key` |
| `/getdirections` | Directions for a route | `key`, `rt` (route ID) |
| `/getstops` | Stops for a route & direction | `key`, `rt`, `dir` |
| `/getpatterns` | Route shape / geo points | `key`, `rt` or `pid` |
| `/getvehicles` | Live vehicle locations | `key`, `vid` or `rt` |
| `/getpredictions` | **ETA predictions** | `key`, `stpid` (stop ID) or `vid` |
| `/getservicebulletins` | Service alerts | `key` |
| `/getrtpidatafeeds` | List available data feeds | `key` |

**Example — Get ETAs at stop 1234 in JSON format:**
```
https://[agency-bustime-host]/bustime/api/v3/getpredictions?key=YOUR_KEY&stpid=1234&format=json
```

**Example — Get all live vehicle positions on Route 10:**
```
https://[agency-bustime-host]/bustime/api/v3/getvehicles?key=YOUR_KEY&rt=10&format=json
```

---

## Agency 1 — PSTA (Pinellas Suncoast Transit Authority)
**Service area:** Pinellas County — St. Petersburg, Clearwater, and surrounding cities.

| Resource | URL |
|---|---|
| **Public ETA Portal** | https://ridepsta.net/bustime/home.jsp |
| **API Base URL** | `https://ridepsta.net/bustime/api/v3/` |
| **API Key Request** | https://ridepsta.net/bustime/createAccount.jsp |
| **API Documentation PDF** | https://ridepsta.net/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf |
| **GTFS Static Feed (ZIP)** | https://www.psta.net/latest/google_transit.zip |
| **GTFS Info Page** | https://ftis.org/Posts.aspx (search "PSTA") |
| **GTFS-RT Real-Time** | Via BusTime API (no open protobuf endpoints) |

**Example ETA call for PSTA:**
```
https://ridepsta.net/bustime/api/v3/getpredictions?key=YOUR_KEY&stpid=3671&format=json
```

---

## Agency 2 — LeeTran (Lee County Transit)
**Service area:** Lee County — Fort Myers, Cape Coral, Bonita Springs, Fort Myers Beach.

| Resource | URL |
|---|---|
| **Public ETA Portal** | https://bustime.leegov.com/bustime/home.jsp |
| **API Base URL** | `https://bustime.leegov.com/bustime/api/v3/` |
| **API Key Request** | https://bustime.leegov.com/bustime/createAccount.jsp |
| **API Documentation PDF** | https://bustime.leegov.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf |
| **GTFS Static Feed (ZIP)** | https://www.leegov.com/leetran/Documents/GTFS.zip |
| **GTFS Info Page** | https://www.leegov.com/leetran/gtfs |
| **GTFS-RT Real-Time** | Via BusTime API (no open protobuf endpoints) |

**Example ETA call for LeeTran:**
```
https://bustime.leegov.com/bustime/api/v3/getpredictions?key=YOUR_KEY&stpid=STOP_ID&format=json
```

---

## Agency 3 — Miami-Dade Transit (MDT)
**Service area:** Miami-Dade County — Metrobus, Metrorail, Metromover.

| Resource | URL |
|---|---|
| **Public ETA Portal** | https://transitbustime.miamidade.gov/ |
| **API Base URL** | `https://transitbustime.miamidade.gov/bustime/api/v3/` |
| **API Key Request** | https://transitbustime.miamidade.gov/bustime/createAccount.jsp |
| **API Documentation PDF** | https://transitbustime.miamidade.gov/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf |
| **GTFS Static Feed (ZIP)** | http://www.miamidade.gov/transit/googletransit/current/google_transit.zip |
| **Open Data Page** | https://www.miamidade.gov/global/transportation/open-data-feeds.page |
| **GTFS-RT (Swiftly API)** | Request access at the Open Data Page above — provides Trip Updates, Vehicle Positions, and Alerts for Metrobus, Metrorail, Metromover, and Coral Gables Trolley |

**Example ETA call for Miami-Dade:**
```
https://transitbustime.miamidade.gov/bustime/api/v3/getpredictions?key=YOUR_KEY&stpid=STOP_ID&format=json
```

---

## Agency 4 — Gainesville RTS (Regional Transit System)
**Service area:** City of Gainesville and University of Florida campus.

| Resource | URL |
|---|---|
| **Public ETA Portal** | https://riderts.app/ |
| **API Base URL** | `https://riderts.app/bustime/api/v3/` |
| **API Key Request** | https://riderts.app/bustime/createAccount.jsp |
| **API Documentation PDF** | https://riderts.app/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf |
| **GTFS Static Feed (ZIP)** | http://go-rts.com/gtfs/google_transit.zip |
| **GTFS Info Page** | https://go-rts.com/rts-data/ |
| **GTFS-RT Real-Time** | Via BusTime API (no open protobuf endpoints) |

**Example ETA call for RTS:**
```
https://riderts.app/bustime/api/v3/getpredictions?key=YOUR_KEY&stpid=STOP_ID&format=json
```

---

## Agency 5 — LYNX (Central Florida Regional Transportation Authority)
**Service area:** Orange, Seminole, and Osceola counties — Orlando metro area.

> **Note:** LYNX is the most open of all 5 agencies. Their GTFS-RT feeds are publicly accessible with **no API key or authentication required**.

| Resource | URL |
|---|---|
| **Public ETA Portal / RT Directory** | http://gtfsrt.golynx.com/gtfsrt/ |
| **API Base URL** | `http://gtfsrt.golynx.com/bustime/api/v3/` |
| **API Key Request** | http://gtfsrt.golynx.com/bustime/createAccount.jsp |
| **API Documentation PDF** | http://gtfsrt.golynx.com/bustime/apidoc/docs/DeveloperAPIGuide3_0.pdf |
| **GTFS Static Feed (ZIP)** | http://gtfsrt.golynx.com/gtfsrt/google_transit.zip |
| **GTFS Info Page** | https://www.golynx.com/maps-schedules/data-download.stml |
| **GTFS-RT Trip Updates** ✅ Open | http://gtfsrt.golynx.com/gtfsrt/GTFS_TripUpdates.pb |
| **GTFS-RT Vehicle Positions** ✅ Open | http://gtfsrt.golynx.com/gtfsrt/GTFS_VehiclePositions.pb |
| **GTFS-RT Service Alerts** ✅ Open | http://gtfsrt.golynx.com/gtfsrt/GTFS_ServiceAlerts.pb |

**Example ETA call for LYNX:**
```
http://gtfsrt.golynx.com/bustime/api/v3/getpredictions?key=YOUR_KEY&stpid=STOP_ID&format=json
```

**Example — Read LYNX GTFS-RT Vehicle Positions in Python (no key needed):**
```python
from google.transit import gtfs_realtime_pb2
import urllib.request

url = "http://gtfsrt.golynx.com/gtfsrt/GTFS_VehiclePositions.pb"
feed = gtfs_realtime_pb2.FeedMessage()
response = urllib.request.urlopen(url)
feed.ParseFromString(response.read())

for entity in feed.entity:
    if entity.HasField("vehicle"):
        v = entity.vehicle
        print(f"Vehicle {v.vehicle.id} | Route {v.trip.route_id} | "
              f"Lat {v.position.latitude} | Lon {v.position.longitude}")
```

---

## Quick Comparison Table

| Agency | County | ETA Portal | GTFS Static | GTFS-RT Open? | API Docs |
|---|---|---|---|---|---|
| **PSTA** | Pinellas | ridepsta.net/bustime | psta.net/latest/google_transit.zip | No (API key needed) | ridepsta.net/bustime/apidoc |
| **LeeTran** | Lee | bustime.leegov.com/bustime | leegov.com/leetran/Documents/GTFS.zip | No (API key needed) | bustime.leegov.com/bustime/apidoc |
| **Miami-Dade** | Miami-Dade | transitbustime.miamidade.gov | miamidade.gov/transit/googletransit/current/google_transit.zip | Via Swiftly (request access) | transitbustime.miamidade.gov/bustime/apidoc |
| **Gainesville RTS** | Alachua | riderts.app | go-rts.com/gtfs/google_transit.zip | No (API key needed) | riderts.app/bustime/apidoc |
| **LYNX** | Orange/Seminole/Osceola | gtfsrt.golynx.com/gtfsrt | gtfsrt.golynx.com/gtfsrt/google_transit.zip | **Yes — fully open** | gtfsrt.golynx.com/bustime/apidoc |

---

*Document prepared by Manus AI — May 2026*
